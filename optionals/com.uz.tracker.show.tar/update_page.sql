INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('show\\page\\EntryPage', 'showEntry', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('show\\page\\CategoryEntryListPage', 'showCategoryEntryList', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('show\\page\\EntryListFeedPage', 'showEntryListFeed', 1);
INSERT INTO	wcf1_user_tracker_page (class, page, isPublic) VALUES ('show\\page\\CategoryEntryListFeedPage', 'showCategoryEntryListFeed', 1);
